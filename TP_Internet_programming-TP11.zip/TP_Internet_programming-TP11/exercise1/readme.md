- Token maker
$: npm i jsonwebtoken

- Express Session
$: npm install express-session
