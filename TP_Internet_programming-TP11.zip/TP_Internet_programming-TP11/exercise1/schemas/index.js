const signUpSchema = require('./signUp');
const signInSchema = require('./signIn');


module.exports = {
  signUpSchema,
  signInSchema
}